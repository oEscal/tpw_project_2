insert into api_position values(1,"Guarda-redes");
insert into api_position values(2,"Defesa");
insert into api_position values(3,"Médio");
insert into api_position values(4,"Avançado");